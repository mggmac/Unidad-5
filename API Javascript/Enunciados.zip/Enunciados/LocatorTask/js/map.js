require(["dojo/parser", "dojo/domReady!"],
 function (parser) {
   // Parse DOM nodes decorated with the data-dojo-type attribute
   parser.parse();
    // Map centered at -117.19, 34.05

});
