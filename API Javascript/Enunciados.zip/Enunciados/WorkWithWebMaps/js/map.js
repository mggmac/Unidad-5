var mapMain;
var legendLayers;
var webmapId;

require([
  "dojo/parser",
  "dojo/domReady!",
], function (parser) {
  parser.parse();

});
